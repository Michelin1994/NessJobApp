const technicians = ['Abdullahi', 'Muftau', 'Daniel', 'Bolaji', 'Clement'];
let loggedInTechnician = ''; // Track the logged-in technician's name

// Function to handle job card submission by drivers
document.getElementById('jobCardForm').addEventListener('submit', function(event) {
    event.preventDefault();

    const driverName = document.getElementById('driverName').value;
    const driverPhone = document.getElementById('driverPhone').value;
    const truckNumber = document.getElementById('truckNumber').value;
    const workDescription = document.getElementById('workDescription').value;
    const date = document.getElementById('date').value;

    addJobCardToData({ driverName, driverPhone, truckNumber, workDescription, date });
    document.getElementById('jobCardForm').reset();
    alert('Job request submitted successfully!');
});

const jobCardData = [];
const assignedTasks = {};

// Function to add job cards to data
function addJobCardToData(card) {
    jobCardData.push(card);
    updateTaskList();
}

// Function to update task list for admin
function updateTaskList() {
    const taskList = document.getElementById('taskList');
    taskList.innerHTML = jobCardData.map((card, index) => `
        <div class="task">
            <p><strong>Truck Number:</strong> ${card.truckNumber}</p>
            <p><strong>Driver:</strong> ${card.driverName}</p>
            <p><strong>Work Description:</strong> ${card.workDescription}</p>
            <p><strong>Date:</strong> ${card.date}</p>
            <button onclick="assignTask(${index})">Assign</button>
        </div>
    `).join('');
}

// Function to assign tasks to technicians
function assignTask(taskIndex) {
    const selectedTechnician = document.getElementById('technicianSelect').value;
    if (!selectedTechnician) {
        alert('Please select a technician!');
        return;
    }
    if (!assignedTasks[selectedTechnician]) {
        assignedTasks[selectedTechnician] = [];
    }
    assignedTasks[selectedTechnician].push(jobCardData[taskIndex]);
    jobCardData.splice(taskIndex, 1);
    updateTaskList();
    alert('Task assigned successfully!');
}

// Admin login
document.getElementById('adminSubmitBtn').addEventListener('click', function() {
    const password = document.getElementById('adminPassword').value;
    if (password === 'admin') {
        document.getElementById('adminLoginForm').style.display = 'none';
        document.getElementById('adminTasks').style.display = 'block';
        updateTaskList(); // Refresh task list after login
    } else {
        alert('Incorrect password!');
    }
});

// Technician/Mechanic login
document.getElementById('techLoginBtn').addEventListener('click', function() {
    const username = document.getElementById('techUsername').value;
    const selectedTechnician = document.getElementById('techSelect').value;

    if (username === 'NESSCO' && selectedTechnician) {
        loggedInTechnician = selectedTechnician;
        document.getElementById('techLoginForm').style.display = 'none';
        document.getElementById('techHeader').style.display = 'block';
        document.getElementById('techTasks').style.display = 'block';
        updateTechTasks(); // Show tasks for the logged-in technician
    } else {
        alert('Invalid username or technician not selected!');
    }
});

// Function to update technician's task list
function updateTechTasks() {
    const techTasks = document.getElementById('techTasks');
    const tasks = assignedTasks[loggedInTechnician] || [];
    if (tasks.length > 0) {
        techTasks.innerHTML = tasks.map(task => `
            <div class="task">
                <p><strong>Truck Number:</strong> ${task.truckNumber}</p>
                <p><strong>Driver:</strong> ${task.driverName}</p>
                <p><strong>Work Description:</strong> ${task.workDescription}</p>
                <p><strong>Date:</strong> ${task.date}</p>
            </div>
        `).join('');
    } else {
        techTasks.innerHTML = '<p>No tasks assigned.</p>';
    }
}

// Function to switch between tabs
document.getElementById('userTabBtn').addEventListener('click', function() {
    showSection('userSection');
});
document.getElementById('adminTabBtn').addEventListener('click', function() {
    showSection('adminSection');
});
document.getElementById('techTabBtn').addEventListener('click', function() {
    showSection('techSection');
});

// Function to show a specific section and hide others
function showSection(sectionId) {
    const sections = ['userSection', 'adminSection', 'techSection'];
    sections.forEach(section => {
        document.getElementById(section).style.display = section === sectionId ? 'block' : 'none';
    });

    // Toggle active class for buttons
    const buttons = document.querySelectorAll('nav button');
    buttons.forEach(button => {
        button.classList.toggle('active', button.id.toLowerCase().includes(sectionId.toLowerCase()));
    });
}

// Populate technician select dropdown
window.onload = function() {
    const technicianSelect = document.getElementById('technicianSelect');
    const techSelect = document.getElementById('techSelect');
    technicians.forEach(tech => {
        technicianSelect.innerHTML += `<option value="${tech}">${tech}</option>`;
        techSelect.innerHTML += `<option value="${tech}">${tech}</option>`;
    });
}

// Function to filter job card data based on the selected time frame
function filterDataByTimeFrame(timeFrame) {
    const now = new Date();
    return jobCardData.filter(card => {
        const cardDate = new Date(card.date);
        switch (timeFrame) {
            case 'yesterday':
                const yesterday = new Date(now);
                yesterday.setDate(now.getDate() - 1);
                return cardDate.toDateString() === yesterday.toDateString();
            case 'last_week':
                const lastWeek = new Date(now);
                lastWeek.setDate(now.getDate() - 7);
                return cardDate >= lastWeek && cardDate <= now;
            case 'last_month':
                const lastMonth = new Date(now);
                lastMonth.setMonth(now.getMonth() - 1);
                return cardDate >= lastMonth && cardDate <= now;
            case 'last_year':
                const lastYear = new Date(now);
                lastYear.setFullYear(now.getFullYear() - 1);
                return cardDate >= lastYear && cardDate <= now;
            case 'all':
            default:
                return true;
        }
    });
}

// Function to download filtered data as Excel file
function downloadExcel() {
    const timeFrame = document.getElementById('timeFrameSelect').value;
    const filteredData = filterDataByTimeFrame(timeFrame);
    let csvContent = "data:text/csv;charset=utf-8,";
    csvContent += "Driver Name,Driver Phone,Truck Number,Work Description,Date\n";

    filteredData.forEach(task => {
        const row = [task.driverName, task.driverPhone, task.truckNumber, task.workDescription, task.date].join(",");
        csvContent += row + "\n";
    });

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `job_card_data_${timeFrame}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}

// Refresh button for admin
document.getElementById('refreshAdminBtn').addEventListener('click', function() {
    updateTaskList();
    alert('Data refreshed successfully!');
});

// Refresh button for technician/mechanic
document.getElementById('refreshTechBtn').addEventListener('click', function() {
    updateTechTasks();
    alert('Tasks refreshed successfully!');
});
